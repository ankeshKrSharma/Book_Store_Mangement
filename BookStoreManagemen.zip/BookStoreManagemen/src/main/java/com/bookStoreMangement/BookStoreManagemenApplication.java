package com.bookStoreMangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreManagemenApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreManagemenApplication.class, args);
	}

}
