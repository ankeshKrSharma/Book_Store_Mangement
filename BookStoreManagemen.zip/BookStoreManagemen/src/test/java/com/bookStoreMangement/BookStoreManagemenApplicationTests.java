package com.bookStoreMangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreManagemenApplicationTests {

	@Test
	void contextLoads() {
	}

}
